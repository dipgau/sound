#include <stdio.h>
// as stub function

void foo(void){
	printf("foo function\n");
	return;
}
